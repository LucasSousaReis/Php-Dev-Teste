<?php


Route::get('/', function () {
    return view('welcome');
});

Route::get('/Agenda/{nome}',function(){
	return redirect('/');
})->where('nome','[A-Za-z]+');

Route::resource('Agenda','AgendaController');
Route::post('getData','AgendaController@getData');
