<template>
	<div>
		
	<nav class="panel column is-offset-2 is-8" >
	  <p class="panel-heading">
	    Agenda
	    <button class="button is-primary is-outlined" @click="openAdd">
	      Adicionar New
	    </button>
	    <span class="is-pulled-right" v-if="loading">
	    	<i class="fa fa-refresh fa-spin fa-2x fa-fw"></i>
	    </span>
	  </p>
	  <div class="panel-block">
	    <p class="control has-icons-left">
	      <input class="input is-small" type="text" placeholder="search" v-model="searchQuery">
	      <span class="icon is-small is-left">
	        <i class="fa fa-search"></i>
	      </span>
	    </p>
	  </div>
	 
	 
	  <a class="panel-block " v-for="item,key in temp">
	  	<span class="column is-9">
	    	{{ item.nome }}
	  	</span>
	    <span class="panel-icon column is-1">
	      <i class="has-text-danger fa fa-trash" aria-hidden="true" @click="del(key,item.id)"></i>
	    </span>
	    <span class="panel-icon column is-1">
	      <i class="has-text-info fa fa-edit" aria-hidden="true" @click="openUpdate(key)"></i>
	    </span><span class="panel-icon column is-1">
	      <i class="has-text-primary fa fa-eye" aria-hidden="true" @click="openShow(key)"></i>
	    </span>
	  </a>
	</nav>

	<Adicionar :openmodal='addActive' @closeRequest='close'></Adicionar>
	<Vizualizar :openmodal='showActive' @closeRequest='close'></Vizualizar>
	<Atualizar :openmodal='updateActive' @closeRequest='close'></Atualizar>
	</div>
</template>

<script>
let Adicionar = require('./Adicionar.vue');
let Vizualizar = require('./Vizualizar.vue');
let Atualizar = require('./Atualizar.vue');
	export default{
		components:{Adicionar,Vizualizar,Atualizar},
		data(){
			return{
				addActive : '',
				showActive : '',
				updateActive : '',
				lists:{},
				errors:{},
				loading:false,
				searchQuery:'',
				temp:''
			}
		},
		watch:{
			searchQuery(){
				if (this.searchQuery.length > 0) {
					this.temp = this.lists.filter((item) => {
						return Object.keys(item).some((key)=>{
							let string = String(item[key]) 
							return string.toLowerCase().indexOf(this.searchQuery.toLowerCase())>-1
							// console.log(string)
						})
					});
					// console.log(result)
				}else{
					this.temp = this.lists
				}
			}
		},
		mounted(){
			axios.post('/getData')
			.then((response)=> this.lists = this.temp = response.data)
			.catch((error) => this.errors = error.response.data.errors)
		},
		methods:{
			openAdd(){
				this.addActive = 'is-active';
			},
			openShow(key){
				this.$children[1].list = this.temp[key]
				this.showActive = 'is-active';
			},
			openUpdate(key){
				this.$children[2].list = this.temp[key]
				this.updateActive = 'is-active';
			},
			close(){
				this.addActive = this.showActive = this.updateActive = ''
			},
			del(key,id){
				if (confirm("Prosseguir?")) {
					this.loading = !this.loading
					axios.delete(`/agenda/${id}`)
					.then((response)=> {this.lists.splice(key,1);this.loading = !this.loading})
					.catch((error) => this.errors = error.response.data.errors)	
				}
				console.log(`${key} ${id}`)
			}
		}
	}
</script>