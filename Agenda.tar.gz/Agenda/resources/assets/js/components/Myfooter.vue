<template>
	<footer class="footer">
  <div class="container">
    <div class="content has-text-centered">
      <p>
        <strong>Vuejs Phonebook App</strong> by <a href="http://bitffumes.com">Sarthak Shrivastava</a>. Access the source code
        <a href="http://github.com/bitfumes/phonebook">Phonebook</a>. 
      </p>
      <p>
        <a class="icon" href="https://github.com/bitfumes">
          <i class="fa fa-github"></i>
        </a>
      </p>
    </div>
  </div>
</footer>
</template>