<template>
	<footer class="footer">
  <div class="container">
    <div class="content has-text-centered">
      <p>
        <a href="https://umobi.com.br/">Agenda</a>. 
      </p>
    </div>
  </div>
</footer>
</template>