<template>
	<div class="modal" :class='openmodal'>
	  <div class="modal-background"></div>
	  <div class="modal-card">
	    <header class="modal-card-head">
	      <p class="modal-card-title">Atualizar {{ list.nome }} Info</p>
	      <button class="delete" aria-label="close" @click='close'></button>
	    </header>
	    <section class="modal-card-body">
	      <div class="field">
	        <label class="label">Nome</label>
	        <div class="control">
	          <input class="input" :class="{'is-danger':errors.nome}" type="text" placeholder="Nome" v-model="list.nome">
	        </div>
	        <small v-if="errors.nome" class="has-text-danger">{{ errors.nome[0] }}</small>
	      </div>

	      <div class="field">
	        <label class="label">Telefone</label>
	        <div class="control">
	          <input class="input" :class="{'is-danger':errors.telefone}" type="number" placeholder="Telefone" v-model="list.telefone">
	        </div>
	        <small v-if="errors.telefone" class="has-text-danger">{{ errors.telefone[0] }}</small>
	      </div>

	   

	    </section>
	    <footer class="modal-card-foot">
	      <button class="button is-success" @click='update'>Atualizar</button>
	      <button class="button" @click='close'>Cancelar</button>
	    </footer>
	  </div>
	</div>
</template>

<script>
	export default{
		props:['openmodal'],
		data(){
			return{
				list:{},
				errors:{}
			}
		},
		methods:{
			close(){
				this.$emit('closeRequest')
			},
			update(){
			axios.patch(`/Agenda/${this.list.id}`,this.$data.list).then((response)=> this.close())
				  .catch((error) => this.errors = error.response.data.errors)
			}
		}
	}
</script>