<template>
	<div class="modal" :class='openmodal'>
	  <div class="modal-background"></div>
	  <div class="modal-card">
	    <header class="modal-card-head">
	      <p class="modal-card-title">{{ list.nome }}'s Details</p>
	      <button class="delete" aria-label="close" @click='close'></button>
	    </header>
	    <section class="modal-card-body">
	    	<li class="panel-block">
	    		<label class="column is-2"><b>Nome</b></label> {{ list.nome }}
	    	</li>

	    	<li class="panel-block">
	    		<label class="column is-2"><b>Telefone</b></label> {{ list.telefone }}
	    	</li>

	    	

	    </section>
	    <footer class="modal-card-foot">
	      <button class="button" @click='close'>Cancelar</button>
	    </footer>
	  </div>
	</div>
</template>
<script>
	export default{
		props:['openmodal'],
		data(){
			return {
				list:''
			}
		},
		methods:{
			close(){
				this.$emit('closeRequest')
			},
		}
	}
</script>




